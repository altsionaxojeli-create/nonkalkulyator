# Tannarx Kalkulyator
1 dona mahsulot tannarxini hisoblaydi. Ma'lumotlar telefonda saqlanadi.
Build: Android Studio -> Build -> Build APK(s)
