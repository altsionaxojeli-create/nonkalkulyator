# Non Kalkulyator — Android APK loyiha

WebView asosidagi ilova. Ma'lumotlar telefonning localStorage xotirasida saqlanadi. Internet talab qilinmaydi.

## 1-usul: Android Studio
1. Papkani Android Studio'da `Open` qiling, Gradle sync tugashini kuting.
2. `Build` -> `Build APK(s)`.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

## 2-usul: GitHub Actions (kompyutersiz)
1. Loyihani GitHub'ga yangi repository qilib yuklang (`.github` papkasi bilan).
2. `Actions` -> `Build APK` -> `Run workflow`.
3. Tugagach, `Artifacts` ichidan `NonKalkulyator-APK` ni yuklab oling, ichidan `app-debug.apk` chiqadi.

Telefonda o'rnatishda "Noma'lum manbalardan o'rnatish"ga ruxsat bering.
